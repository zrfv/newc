app.post('/contactProc', (req, res) => {
    const name = req.body.name; 
    const memo = req.body.memo; 
  
    var sql = `insert into contact(name,memo,regdate)
    values(?,?,now() )`
     
    var values = [name,memo]; 
 
    connection.query(sql, values, function (err, result){
        if(err) throw err; 
        console.log('자료 1개를 삽입하였습니다.');
        res.send("<script> alert('문의사항이 등록되었습니다.');</script>"); 
    })
 
 })
 