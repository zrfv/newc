"use strict";
const db = require("./src/config/db");
// 모듈
const express = require("express");
const bodyParser = require("body-parser");
const ejs = require('ejs') /////
const dotenv = require("dotenv");
var session = require('express-session') /////
dotenv.config();

const app = express();

// 라우팅
const home = require("./src/routes/home");

 

app.use(session({ secret: 'unidago', cookie: { maxAge: 60000 }, resave:true, saveUninitialized:true, })) /////

// 앱 세팅
app.set("views", "./src/views");
app.set("view engine", "ejs");
app.use(express.static(`${__dirname}/src/public`));
app.use(bodyParser.json());
// URL을 통해 전달되는 데이터에 한글, 공백 등과 같은 문자가 포함될 경우 제대로 인식되지 않는 문제 해결
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/", home); // use -> 미들 웨어를 등록해주는 메서드.

app.get('/contact', (req, res) => { /////
    res.render('contact')  // ./views/contact.ejs
 })

 app.post('/contactProc', (req, res) => {
    const name = req.body.name; 
    const memo = req.body.memo; 
  
    var sql = `insert into contact(name,memo,regdate)
    values(?,?,now() )`
     
    var values = [name,memo]; 
 
    db.query(sql, values, function (err, result){
        if(err) throw err; 
        console.log('등록 완료.');
        res.send("<script> alert('등록이 완료되었습니다. 좋은 하루 되세요.'); location.href='/contact';</script>"); 
    })
 
 })


 app.get('/contactDelete', (req, res) => {
    var idx = req.query.idx 
    var sql = `delete from contact where idx='${idx}' `
    db.query(sql, function (err, result){
       if(err) throw err; 
       
       res.send("<script> alert('삭제되었습니다.'); location.href='/contactList';</script>"); 
   })
 })
 
app.get('/contactList', (req, res) => {
 
    var sql = `select * from contact order by idx desc `
    db.query(sql, function (err, results, fields){
       if(err) throw err; 
       res.render('contactList',{lists:results})
    })
    
 })

module.exports = app;
