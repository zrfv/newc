const mysql = require("mysql");

const db = mysql.createConnection({
  host: "computing-23.cf51xrc5gtyt.ap-northeast-2.rds.amazonaws.com",
  user: "admin",
  password: "duddh0505",
  database: "computing_23",
});

db.connect();

module.exports = db;
